
# IPhone Store

Site institucional com catálogo de iPhones, login, cadastro e tela de boas-vindas.

## Funcionalidades

- Tela de boas-vindas animada
- Login e cadastro na mesma página com validações
- Redirecionamento automático do splash para login
- Design responsivo

## Publicação com GitHub Pages

1. Vá até **Settings > Pages**
2. Em **Source**, selecione `main` e `/ (root)`
3. Clique em **Save**
4. Acesse pelo link gerado, que será algo como:
   `https://seu-usuario.github.io/iphone-store`
