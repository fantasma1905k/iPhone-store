
function criarConta() {
  const nome = document.getElementById('cadastro-nome').value.trim();
  const email = document.getElementById('cadastro-email').value.trim();
  const senha = document.getElementById('cadastro-senha').value;
  const confirmarSenha = document.getElementById('confirmar-senha').value;
  const erro = document.getElementById('cadastro-erro');

  erro.textContent = '';

  if (!nome || !email || !senha || !confirmarSenha) {
    erro.textContent = 'Por favor, preencha todos os campos.';
    return;
  }

  if (!email.includes('@') || !email.includes('.')) {
    erro.textContent = 'Insira um e-mail válido.';
    return;
  }

  if (senha !== confirmarSenha) {
    erro.textContent = 'As senhas não coincidem.';
    return;
  }

  localStorage.setItem('usuario', JSON.stringify({ nome, email, senha }));
  alert('Conta criada com sucesso!');
  mostrarLogin();
}

function fazerLogin() {
  const email = document.getElementById('login-email').value.trim();
  const senha = document.getElementById('login-senha').value;
  const erro = document.getElementById('login-erro');

  erro.textContent = '';

  const usuario = JSON.parse(localStorage.getItem('usuario'));

  if (!usuario || email !== usuario.email || senha !== usuario.senha) {
    erro.textContent = 'Email ou senha inválidos.';
    return;
  }

  alert('Login bem-sucedido!');
  window.location.href = 'index.html';
}

function mostrarCadastro() {
  const form = document.getElementById('form-container');
  form.classList.remove('fade-in');
  form.classList.add('fade-out');
  setTimeout(() => {
    document.getElementById('form-login').style.display = 'none';
    document.getElementById('form-cadastro').style.display = 'block';
    form.classList.remove('fade-out');
    form.classList.add('fade-in');
  }, 300);
}

function mostrarLogin() {
  const form = document.getElementById('form-container');
  form.classList.remove('fade-in');
  form.classList.add('fade-out');
  setTimeout(() => {
    document.getElementById('form-cadastro').style.display = 'none';
    document.getElementById('form-login').style.display = 'block';
    form.classList.remove('fade-out');
    form.classList.add('fade-in');
  }, 300);
}
